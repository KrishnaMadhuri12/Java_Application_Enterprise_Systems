/*************************************************************
* File:AdvisorClient.java
* Project: AppointmentSystem
* Versions:
*	1.1	February 2017
*
* Description:
* This class acts as the client with main program and reads keyboard inputs. 
* The face of advisor system starts with this class
* @author Krishna Madhuri
**************************************************************/

package com.university.app;

import java.util.Scanner;

import com.university.dto.Advisor;

import com.university.exception.InvalidAdvisorId;
import com.university.impl.AdvisorServiceImp;



public class AdvisorClient {
	static Scanner sc=new Scanner(System.in);
	/**
	 * @param args
	 * @throws InvalidAdvisorId 
	 */
	public static void main(String[] args) throws InvalidAdvisorId {
		// TODO Auto-generated method stub
		System.out.println("Enter S for student and A advisor to proceed");
		
		AdvisorServiceImp advisorController=new AdvisorServiceImp();
		
		
			System.out.println("Welcome to Appointment System");
			System.out.println("Enter Advisor ID");
			int id=sc.nextInt();
			int aptId,reqSlotId;
			Advisor advisorDetails=advisorController.verifyAdvisor(id);
			String mychoice="y";
			do{
				System.out.println("Welcome"+advisorDetails.getAdvisor_name());
				System.out.println("select an option");
				System.out.println("1. view appointment");
				System.out.println("2. book appointment");
				System.out.println("3. modify appointment");
				System.out.println("4. cancel appointment");
				
				int option = sc.nextInt();
				switch (option) {
				case 1:
					advisorController.viewAppointments(advisorDetails);
					break;
				case 2:
					System.out.println("Enter the StudentId");
					int sid=sc.nextInt();
					advisorController.viewTimeSlot(advisorDetails);
					System.out.println("Enter the selected TimeSlot id:");
					advisorController.bookAppointment(advisorDetails,sc.nextInt(),sid);
					break;
				case 3:
					System.out.println("Enter the appointmentId:");
					aptId=sc.nextInt();
					System.out.println("Select the next available time slots for the advisor");
					System.out.println("Please note the slot status 1 represents available for scheduling appointment");
					advisorController.viewTimeSlot(advisorDetails);
					reqSlotId=sc.nextInt();
					advisorController.modifyAppointment(aptId,reqSlotId);
					break;
				case 4: 
					System.out.println("Enter the appointmentId:");
					aptId=sc.nextInt();
					advisorController.cancelAppointment(advisorDetails,aptId);
					break;
				
				default:
					System.out.println("please select valid option");
					break;
				}
				
				System.out.println("Do you want to continue(y/n)");
				mychoice = sc.next();
			}while(mychoice.equalsIgnoreCase("y"));
		
	}
}
