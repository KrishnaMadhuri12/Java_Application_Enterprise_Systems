/*************************************************************
* File: StudentClient.java
* Project: AppointmentSystem
* Versions:
*	1.1	February 2017
*
* Description:
* This class acts as the client with main program and reads keyboard inputs. 
* The face of student system starts with this class
* 
* @author Krishna Madhuri
**************************************************************/

package com.university.app;

import java.util.Scanner;

import com.university.dto.Student;
import com.university.exception.InvalidStudentId;
import com.university.impl.StudentServiceImp;
public class StudentClient {
	static Scanner sc=new Scanner(System.in);
	/**
	 * @param args
	 * @throws InvalidStudentId 
	 */
	public static void main(String[] args) throws InvalidStudentId {
		// TODO Auto-generated method stub
		System.out.println("Enter S for student and A advisor to proceed");
		
		StudentServiceImp studentController=new StudentServiceImp();
		
		
			System.out.println("Welcome to Appointment System");
			System.out.println("Enter student ID");
			int id=sc.nextInt();
			int aptId,reqSlotId;
			Student studentDetails=studentController.verifyStudent(id);
			String mychoice="y";
			do{
				System.out.println("Welcome"+studentDetails.getStudent_name());
				System.out.println("select an option");
				System.out.println("1. view appointment");
				System.out.println("2. book appointment");
				System.out.println("3. modify appointment");
				System.out.println("4. cancel appointment");
				int option = sc.nextInt();
				switch (option) {
				case 1:
					studentController.viewAppointments(studentDetails);
					break;
				case 2:
					studentController.viewTimeSlot(studentDetails);
					System.out.println("Enter the selected TimeSlot id:");
					studentController.bookAppointment(studentDetails,sc.nextInt());
					break;
				case 3:
					System.out.println("Enter the appointmentId:");
					aptId=sc.nextInt();
					System.out.println("Select the next available time slots for the advisor");
					System.out.println("Please note the slot status 1 represents available for scheduling appointment");
					studentController.viewTimeSlot(studentDetails);
					
					reqSlotId=sc.nextInt();
					studentController.modifyAppointment(studentDetails,aptId,reqSlotId);
					break;
				case 4: 
					System.out.println("Enter the appointmentId:");
					aptId=sc.nextInt();
					studentController.cancelAppointment(studentDetails,aptId);
					break;

				default:
					System.out.println("please select valid option");
					break;
				}
				
				System.out.println("Do you want to continue(y/n)");
				mychoice = sc.next();
			}while(mychoice.equalsIgnoreCase("y"));
		
		

	}
	

}
