/**
 * 
 */
package com.university.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 * @author Madhuri
 *
 */
public class ConnectionFactory {
	private static ConnectionFactory instance=null;
	private final String Driverr_Class="com.mysql.jdbc.Driver";
	private final static String DB_URL="jdbc:mysql://localhost/university";
	private final static String USER_NAME="root";
	private final static String PASSWORD="root";

	//private constructor
	private ConnectionFactory()
	{
		try{
			Class.forName(Driverr_Class);
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	}//constructor

	public static ConnectionFactory getInstance(){
		
		if(instance==null){
			//synchronized block to double check
			instance=new ConnectionFactory();
		}
		return instance;
	}

	public Connection getConnection() throws SQLException
	{
		return DriverManager.getConnection(DB_URL,USER_NAME,PASSWORD);
	}
}
