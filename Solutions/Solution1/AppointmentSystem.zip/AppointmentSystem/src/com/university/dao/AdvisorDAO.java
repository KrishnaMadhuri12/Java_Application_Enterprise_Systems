/*************************************************************
* File:AdvisorDAO.java
* Project: AppointmentSystem
* Versions:
*	1.1	February 2017
*
* Description:
* This class interacts with the database using prepared statements a
* nd stores the result in result sets. 
* The functionalities in the advisor module are implemented in this class.
* @author Krishna Madhuri
**************************************************************/
package com.university.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.university.connection.ConnectionFactory;
import com.university.dto.Advisor;
import com.university.dto.Appointment;

import com.university.dto.TimeSlot;
import com.university.exception.InvalidAdvisorId;

public class AdvisorDAO {
	
	private Connection connection = null;
	private PreparedStatement pstmt = null;
	private ResultSet resultSet = null;
	private ConnectionFactory connectionFactory = null;
	
	
	public AdvisorDAO()
	{
		connectionFactory=ConnectionFactory.getInstance();
	}

	public Advisor verifyAdvisor(int id) throws InvalidAdvisorId {
		Advisor advisorDetails = null;
		try{
			connection=connectionFactory.getConnection();
			String selectQuery="Select advId,advisor_name, advisor_dept from advisor where advId=?";
			pstmt=connection.prepareStatement(selectQuery);
			pstmt.setInt(1, id);
			resultSet =pstmt.executeQuery();
		if(resultSet.next())
		{
			advisorDetails= new Advisor(resultSet.getInt(1),resultSet.getString(2), resultSet.getString(3));	
		}
		else{
		throw new InvalidAdvisorId("Advisor id not found");
		}
	}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}

		return advisorDetails;
		}
	public void viewAppointments(Advisor advisorDetails) {
		List<Appointment> appointmentList = new ArrayList<Appointment>();
		try{
			connection=connectionFactory.getConnection();
			String selectQuery="select apt_Id,student_Id, Advisor_Id, slot_Id, apt_Status from appointment where Advisor_Id=?";
			pstmt=connection.prepareStatement(selectQuery);
			pstmt.setInt(1,advisorDetails.getAdvID());
			resultSet =pstmt.executeQuery();
	while(resultSet.next()){
		Appointment appointmentDetails=new Appointment();
		appointmentDetails.setApt_Id(resultSet.getInt(1));
		appointmentDetails.setStudent_Id(resultSet.getInt(2));
		appointmentDetails.setAdvisor_Id(resultSet.getInt(3));
		appointmentDetails.setSlot_id(resultSet.getInt(4));
		appointmentDetails.setApt_Status(resultSet.getString(5));
		appointmentList.add(appointmentDetails);
		
		
	}
	if(appointmentList.size()<=0){
		System.out.println("Please make an appointment");
		
	}
	else
	{
		System.out.println("Scheduled Appointments are:");
		System.out.println(appointmentList);
		
	}
			}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}

	
	}

	public void bookAppointment(Advisor advisorDetails, int id,int studentId) {
		   	try{
				connection=connectionFactory.getConnection();
				String selectQuery="select count(Apt_Id) from appointment;";
				pstmt=connection.prepareStatement(selectQuery);
				resultSet =pstmt.executeQuery();
				int apt_Id = 0;
				if(resultSet.next())
					{
					apt_Id=resultSet.getInt(1);
					}
				String insertQuery="insert into appointment(Apt_Id, Student_Id, Advisor_Id, slot_Id, Apt_Status) values(?,?,?,?,?);";
				pstmt=connection.prepareStatement(insertQuery);
				pstmt.setInt(1,apt_Id+1 );
				pstmt.setInt(2, studentId);
				pstmt.setInt(3, advisorDetails.getAdvID());
				pstmt.setInt(4, id);
				pstmt.setString(5,"Upcoming");
				int rowsAffected1 =pstmt.executeUpdate();
			if(rowsAffected1==0)
			{
				System.out.println("Please select another time slot.");
				
			}
			else
			{
				System.out.println("Slot Booked!!");
				updateTimeSlot(id,0);	//Making the time slot unavailable for future appointments schedule
			}
			
			}
			catch(SQLException e){
				System.out.println("SQL exception");
				e.printStackTrace();
			}
		
	}

	public void modifyAppointment(int apt_id,int reqtimeSlotId) {
		try{
			connection=connectionFactory.getConnection();
			int timeSlotId=getSlotId(apt_id);
			if(timeSlotId!=0){
			
			String deleteQuery="update appointment set slot_id=? where apt_id=?";
			pstmt=connection.prepareStatement(deleteQuery);
			pstmt.setInt(1, reqtimeSlotId);
			pstmt.setInt(2, apt_id);
			int  count =pstmt.executeUpdate();
			if(count==1){
				System.out.println("Appointment is Modified");
				updateTimeSlot(timeSlotId,1); //Making the booked slot available again	
							
			}
			else
			{
				System.out.println("Could not complete the request");
			}
			}
		}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}
		
	}
/**
 * 
 * @param advisorDetails
 * @param apt_id//appointmentId
 */
	public void cancelAppointment(Advisor advisorDetails, int apt_id) {
		try{
			connection=connectionFactory.getConnection();
			int Slot_Id=getSlotId(apt_id);
			if(Slot_Id!=0)
			{
				String deleteQuery="delete from appointment where Advisor_Id=? and apt_Id=? and apt_Status=?";
			pstmt=connection.prepareStatement(deleteQuery);
			pstmt.setInt(1, advisorDetails.getAdvID());
			pstmt.setInt(2, apt_id);
			pstmt.setString(3, "Upcoming");
			int  count =pstmt.executeUpdate();
			if(count==1){
				System.out.println("Appointment is Cancelled");
				updateTimeSlot(Slot_Id,1);	// Making the slot available				
							
			}
			
			else
			{
				System.out.println("Could not complete the request");
			}
			}
		}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}

	}

	public void viewTimeSlot(Advisor advisorDetails) {
		// TODO Auto-generated method stub
		List<TimeSlot> timeSlotList = new ArrayList<TimeSlot>();
		
		try{
			connection=connectionFactory.getConnection();
			String selectQuery="select slot_id, slot_start, slot_end,advisor_assigned, slot_status from timeslot where advisor_assigned=? and slot_status=?";
			pstmt=connection.prepareStatement(selectQuery);
			pstmt.setInt(1, advisorDetails.getAdvID());
			pstmt.setInt(2,1);	// where int value 1 represents for free advising time slots
			resultSet =pstmt.executeQuery();
		if(resultSet.next())
		{
			TimeSlot slotDetails=new TimeSlot();
			slotDetails.setSlot_id(resultSet.getInt(1));
			slotDetails.setSlot_start(resultSet.getDate(2));
			slotDetails.setSlot_end(resultSet.getDate(3));
			slotDetails.setAdvisor_assigned(resultSet.getInt(4));
			slotDetails.setSlot_status(resultSet.getInt(5));
			timeSlotList.add(slotDetails);
			
		}
		if(timeSlotList.size()<=0){
			System.out.println("Please make an appointment");
			
		}
		else
		{
			System.out.println("Available TimeSlots are:");
			System.out.println(timeSlotList);
			
		}		
		}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}
		
	}
	
	public int getSlotId(int id){
		int timeSlot=0;
		try{
			connection=connectionFactory.getConnection();
			String selectQuery="select slot_id from appointment where apt_Id=?";
			pstmt=connection.prepareStatement(selectQuery);
			pstmt.setInt(1, id);
			resultSet=pstmt.executeQuery();
			
			if(resultSet.next())
			{
				timeSlot=resultSet.getInt(1);
				return timeSlot;
			}
			
		}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}
		return timeSlot;
	}
	
	public void updateTimeSlot(int id, int statusChange)
	{try{
		connection=connectionFactory.getConnection();
		String updateSlot="update  timeslot set slot_status=? where slot_id=?";
		pstmt=connection.prepareStatement(updateSlot);
		pstmt.setInt(1,id);
		pstmt.setInt(2,statusChange);
		int  rows =pstmt.executeUpdate();
		if(rows!=0){
			System.out.println("Slot updated");
		}
	}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}
	}

	
}
