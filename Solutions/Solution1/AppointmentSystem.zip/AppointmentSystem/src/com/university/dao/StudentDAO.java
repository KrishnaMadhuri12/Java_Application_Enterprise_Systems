/*************************************************************
* File: StudentDAO.java
* Project: AppointmentSystem
* Versions:
*	1.1	February 2017
*
* Description:
* This class interacts with the database using prepared statements and stores the result in result sets. 
* The functionalities in the advisor module are implemented in this class.
* 
* @author Krishna Madhuri
**************************************************************/
package com.university.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.university.exception.InvalidStudentId;
import com.university.connection.ConnectionFactory;
import com.university.dto.Appointment;
import com.university.dto.Student;
import com.university.dto.TimeSlot;


public class StudentDAO {
	private Connection connection = null;
	private PreparedStatement pstmt = null;
	private ResultSet resultSet = null;
	private ConnectionFactory connectionFactory = null;
	
	public StudentDAO()
	{
		connectionFactory=ConnectionFactory.getInstance();
	}

	public Student verifyStudent(int id) throws InvalidStudentId {
		Student studentDetails = null;
		try{
			connection=connectionFactory.getConnection();
			String selectQuery="Select student_id, student_name, student_department, advisor_id from student where student_id=?";
			pstmt=connection.prepareStatement(selectQuery);
			pstmt.setInt(1, id);
			resultSet =pstmt.executeQuery();
		if(resultSet.next())
		{
			studentDetails= new Student(resultSet.getInt(1),resultSet.getString(2), resultSet.getString(3), resultSet.getInt(4));	
		}
		else
		{
		throw new InvalidStudentId("student id not found");}
		}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}

		return studentDetails;
		}
	
	public void viewAppointments(Student studentDetails) {
		List<Appointment> appointmentList = new ArrayList<Appointment>();
		try{
			connection=connectionFactory.getConnection();
			String selectQuery="select apt_Id,student_Id, Advisor_Id, slot_Id, apt_Status from appointment where student_id=?";
			pstmt=connection.prepareStatement(selectQuery);
			pstmt.setInt(1,studentDetails.getStudent_id());
			resultSet =pstmt.executeQuery();
	while(resultSet.next()){
		Appointment appointmentDetails=new Appointment();
		appointmentDetails.setApt_Id(resultSet.getInt(1));
		appointmentDetails.setStudent_Id(resultSet.getInt(2));
		appointmentDetails.setAdvisor_Id(resultSet.getInt(3));
		appointmentDetails.setSlot_id(resultSet.getInt(4));
		appointmentDetails.setApt_Status(resultSet.getString(5));
		appointmentList.add(appointmentDetails);
		
		
	}
	if(appointmentList.size()<=0){
		System.out.println("Please make an appointment");
		
	}
	else
	{
		System.out.println("Scheduled Appointments are:");
		System.out.println(appointmentList);
		
	}
			}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}

	
	}

	public void bookAppointment(Student studentDetails, int id) {
		   	try{
				connection=connectionFactory.getConnection();
				String selectQuery="select count(Apt_Id) from appointment;";
				pstmt=connection.prepareStatement(selectQuery);
				resultSet =pstmt.executeQuery();
				int apt_Id = 0;
				if(resultSet.next())
					{
					apt_Id=resultSet.getInt(1);
					}
				String insertQuery="insert into appointment(Apt_Id, Student_Id, Advisor_Id, slot_Id, Apt_Status) values(?,?,?,?,?);";
				pstmt=connection.prepareStatement(insertQuery);
				pstmt.setInt(1,apt_Id+1 );
				pstmt.setInt(2, studentDetails.getStudent_id());
				pstmt.setInt(3, studentDetails.getAdvisor_id());
				pstmt.setInt(4, id);
				pstmt.setString(5,"Upcoming");
				int rowsAffected1 =pstmt.executeUpdate();
			if(rowsAffected1==0)
			{
				System.out.println("Please select another time slot.");
				
			}
			else
			{
				System.out.println("Slot Booked!!");
				updateTimeSlot(id,0);	//Making the time slot unavailable for future appointments schedule
			}
			
			}
			catch(SQLException e){
				System.out.println("SQL exception");
				e.printStackTrace();
			}
		
	}

	public void modifyAppointment(Student studentDetails, int id,int reqtimeSlotId) {
		try{
			connection=connectionFactory.getConnection();
			int timeSlotId=getSlotId(id);
			if(timeSlotId!=0){
			
			String deleteQuery="update appointment set slot_id=? where apt_id=?";
			pstmt=connection.prepareStatement(deleteQuery);
			pstmt.setInt(1, reqtimeSlotId);
			pstmt.setInt(2, id);
			int  count =pstmt.executeUpdate();
			if(count==1){
				System.out.println("Appointment is Modified");
				updateTimeSlot(timeSlotId,1); //Making the booked slot available again	
							
			}
			else
			{
				System.out.println("Could not complete the request");
			}
			}
		}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}
		
	}

	public void cancelAppointment(Student studentDetails, int id) {
		try{
			connection=connectionFactory.getConnection();
			int Slot_Id=getSlotId(id);
			if(Slot_Id!=0)
			{
				String deleteQuery="delete from appointment where student_id=? and apt_Id=? and apt_Status=?";
			pstmt=connection.prepareStatement(deleteQuery);
			pstmt.setInt(1, studentDetails.getStudent_id());
			pstmt.setInt(2, id);
			pstmt.setString(3, "Upcoming");
			int  count =pstmt.executeUpdate();
			if(count==1){
				System.out.println("Appointment is Cancelled");
				updateTimeSlot(Slot_Id,1);	// Making the slot available				
							
			}
			
			else
			{
				System.out.println("Could not complete the request");
			}
			}
		}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}

	}

	public void viewTimeSlot(Student studentDetails) {
		// TODO Auto-generated method stub
		List<TimeSlot> timeSlotList = new ArrayList<TimeSlot>();
		
		try{
			connection=connectionFactory.getConnection();
			String selectQuery="select slot_id, slot_start, slot_end,advisor_assigned, slot_status from timeslot where advisor_assigned=? and slot_status=?";
			pstmt=connection.prepareStatement(selectQuery);
			pstmt.setInt(1, studentDetails.getAdvisor_id());
			pstmt.setInt(2,1);	// where int value 1 represents for free advisor slots
			resultSet =pstmt.executeQuery();
		if(resultSet.next())
		{
			TimeSlot slotDetails=new TimeSlot();
			slotDetails.setSlot_id(resultSet.getInt(1));
			slotDetails.setSlot_start(resultSet.getDate(2));
			slotDetails.setSlot_end(resultSet.getDate(3));
			slotDetails.setAdvisor_assigned(resultSet.getInt(4));
			slotDetails.setSlot_status(resultSet.getInt(5));
			timeSlotList.add(slotDetails);
			
		}
		if(timeSlotList.size()<=0){
			System.out.println("Please make an appointment");
			
		}
		else
		{
			System.out.println("Available TimeSlots are:");
			System.out.println(timeSlotList);
			
		}		
		}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}
		
	}
	
	public int getSlotId(int id){
		int timeSlot=0;
		try{
			connection=connectionFactory.getConnection();
			String selectQuery="select slot_id from appointment where apt_Id=?";
			pstmt=connection.prepareStatement(selectQuery);
			pstmt.setInt(1, id);
			resultSet=pstmt.executeQuery();
			
			if(resultSet.next())
			{
				timeSlot=resultSet.getInt(1);
				return timeSlot;
			}
			
		}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}
		return timeSlot;
	}
	
	public void updateTimeSlot(int id, int statusChange)
	{try{
		connection=connectionFactory.getConnection();
		String updateSlot="update  timeslot set slot_status=? where slot_id=?";
		pstmt=connection.prepareStatement(updateSlot);
		pstmt.setInt(1,id);
		pstmt.setInt(2,statusChange);
		int  rows =pstmt.executeUpdate();
		if(rows!=0){
			System.out.println("Slot updated");
		}
	}
		catch(SQLException e){
			System.out.println("SQL exception");
			e.printStackTrace();
		}
	}
	
}
