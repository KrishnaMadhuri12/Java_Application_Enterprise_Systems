package com.university.daoTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.university.dao.AdvisorDAO;
import com.university.dto.Advisor;
import com.university.exception.InvalidAdvisorId;



public class AdvisorDAOTest {
AdvisorDAO advisorRef=new AdvisorDAO();
	
	@Test
	public void testVerifyStudent(){
		int id=1001;
		try {
			Advisor advisorDetails=advisorRef.verifyAdvisor(id);
			Advisor expectedDetails=new Advisor(1001,"Drake","CS");
			assertEquals(advisorDetails.getAdvID(),expectedDetails.getAdvID());
			} catch (InvalidAdvisorId e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetSlotId()
	{
	int actual= advisorRef.getSlotId(1);
	int expected=1;
	assertEquals(expected, actual);
	}
	
}
