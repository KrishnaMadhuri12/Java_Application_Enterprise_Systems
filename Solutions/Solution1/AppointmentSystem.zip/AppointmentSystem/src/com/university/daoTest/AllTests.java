package com.university.daoTest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AdvisorDAOTest.class, StudentDAOTest.class })
public class AllTests {

}
