package com.university.daoTest;

import static org.junit.Assert.*;

import org.junit.Test;

import com.university.dao.StudentDAO;
import com.university.dto.Student;
import com.university.exception.InvalidStudentId;

public class StudentDAOTest {
	StudentDAO studentRef=new StudentDAO();
	
	@Test
	public void testVerifyStudent(){
		int id=100;
		try {
			Student studentDetails=studentRef.verifyStudent(id);
			Student expectedDetails= new Student(100,"student1","CS",1001);
			assertEquals(expectedDetails.getAdvisor_id(),studentDetails.getAdvisor_id());
			} catch (InvalidStudentId e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetSlotId()
	{
	int actual= studentRef.getSlotId(1);
	int expected=1;
	assertEquals(expected, actual);
	}
	

}
