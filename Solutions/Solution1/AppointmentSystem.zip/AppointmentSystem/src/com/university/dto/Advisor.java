/*************************************************************
* File:Advisor.java
* Project: AppointmentSystem
* Versions:
*	1.1	February 2017
*
* Description:
* The plain old java object to store the data query results 
* and pass on the data in between the project
* 
* @author Krishna Madhuri
**************************************************************/
package com.university.dto;

public class Advisor {
	private int advID;
	private String advisor_name;
	private String advisor_dept;
	
	public Advisor(int advID, String advisor_name, String advisor_dept) {
		super();
		this.advID = advID;
		this.advisor_name = advisor_name;
		this.advisor_dept = advisor_dept;
	}

	public int getAdvID() {
		return advID;
	}

	public void setAdvID(int advID) {
		this.advID = advID;
	}

	public String getAdvisor_name() {
		return advisor_name;
	}

	public void setAdvisor_name(String advisor_name) {
		this.advisor_name = advisor_name;
	}

	public String getAdvisor_dept() {
		return advisor_dept;
	}

	public void setAdvisor_dept(String advisor_dept) {
		this.advisor_dept = advisor_dept;
	}
}
