/*************************************************************
* File:Appointment.java
* Project: AppointmentSystem
* Versions:
*	1.1	February 2017
*
* Description:
* The plain old java object to store the data query results 
* and pass on the data in between the project
* 
* @author Krishna Madhuri
**************************************************************/
package com.university.dto;

public class Appointment {

	private int Apt_Id;
	private int Student_Id;
	private int Advisor_Id;
	private int slot_id;
	private String Apt_Status;
	
	public int getApt_Id() {
		return Apt_Id;
	}

	public void setApt_Id(int apt_Id) {
		Apt_Id = apt_Id;
	}

	public int getStudent_Id() {
		return Student_Id;
	}

	public void setStudent_Id(int student_Id) {
		Student_Id = student_Id;
	}

	public int getAdvisor_Id() {
		return Advisor_Id;
	}

	public void setAdvisor_Id(int advisor_Id) {
		Advisor_Id = advisor_Id;
	}

	public int getSlot_id() {
		return slot_id;
	}

	public void setSlot_id(int slot_id) {
		this.slot_id = slot_id;
	}

	public String getApt_Status() {
		return Apt_Status;
	}

	public void setApt_Status(String apt_Status) {
		Apt_Status = apt_Status;
	}

	public Appointment(int apt_Id, int student_Id, int advisor_Id, int slot_id,
			String apt_Status) {
		super();
		Apt_Id = apt_Id;
		Student_Id = student_Id;
		Advisor_Id = advisor_Id;
		this.slot_id = slot_id;
		Apt_Status = apt_Status;
	}

	public Appointment() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "AppointmentId:" + Apt_Id + ", AdvisorId= " + Advisor_Id + ", ScheduledSlot =" + slot_id
				+ ", AppointmentStatus=" + Apt_Status;
	}
}
