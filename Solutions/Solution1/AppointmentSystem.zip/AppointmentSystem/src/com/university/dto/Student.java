/*************************************************************
* File: Student.java
* Project: AppointmentSystem
* Versions:
*	1.1	February 2017
*
* Description:
* The plain old java object to store the data query results 
* and pass on the data in between the project
* 
* @author Krishna Madhuri
**************************************************************/
package com.university.dto;

public class Student {

	private int student_id;
	private String student_name;
	private String student_department;
	private int advisor_id;
	public int getStudent_id() {
		return student_id;
	}
	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public Student(int student_id, String student_name,
			String student_department, int advisor_id) {
		super();
		this.student_id = student_id;
		this.student_name = student_name;
		this.student_department = student_department;
		this.advisor_id = advisor_id;
	}
	public Student() {
		// TODO Auto-generated constructor stub
	}
	public String getStudent_department() {
		return student_department;
	}
	public void setStudent_department(String student_department) {
		this.student_department = student_department;
	}
	public int getAdvisor_id() {
		return advisor_id;
	}
	public void setAdvisor_id(int advisor_id) {
		this.advisor_id = advisor_id;
	}
	
	
}
