/*************************************************************
* File: TimeSlot.java
* Project: AppointmentSystem
* Versions:
*	1.1	February 2017
*
* Description:
* The plain old java object to store the data query results 
* and pass on the data in between the project
* 
* @author Krishna Madhuri
**************************************************************/
package com.university.dto;

import java.util.Date;

public class TimeSlot {

	private int slot_id;
	private Date slot_start;
	private Date slot_end;
	private int advisor_assigned;
	private int slot_status; //0 for blocked and 1 for open
	public TimeSlot(int slot_id, Date slot_start, Date slot_end,
			int advisor_assigned, int slot_status) {
		super();
		this.slot_id = slot_id;
		this.slot_start = slot_start;
		this.slot_end = slot_end;
		this.advisor_assigned = advisor_assigned;
		this.slot_status = slot_status;
	}
	
	@Override
	public String toString() {
		return "TimeSlotId: " + slot_id + ", Start Time=" + slot_start
				+ ", End Time=" + slot_end + ", Assigned Advisor Id="
				+ advisor_assigned + ", Slot Status=" + slot_status;
	}
	public TimeSlot() {
		// TODO Auto-generated constructor stub
	}
	public int getSlot_id() {
		return slot_id;
	}
	public void setSlot_id(int slot_id) {
		this.slot_id = slot_id;
	}
	public Date getSlot_start() {
		return slot_start;
	}
	public void setSlot_start(Date slot_start) {
		this.slot_start = slot_start;
	}
	public Date getSlot_end() {
		return slot_end;
	}
	public void setSlot_end(Date slot_end) {
		this.slot_end = slot_end;
	}
	public int getAdvisor_assigned() {
		return advisor_assigned;
	}
	public void setAdvisor_assigned(int advisor_assigned) {
		this.advisor_assigned = advisor_assigned;
	}
	public int getSlot_status() {
		return slot_status;
	}
	public void setSlot_status(int slot_status) {
		this.slot_status = slot_status;
	}
	
	
}
