/*************************************************************
* File: InvalidAdvisor.java
* Project: AppointmentSystem
* Versions:
*	1.1	February 2017
*
* Description:
* This an exception which is thrown when the provided Advisor Id does not exist in system
* 
* @author Krishna Madhuri
**************************************************************/
package com.university.exception;


public class InvalidAdvisorId extends Exception {
	private static final long serialVersionUID = 8564036433255637794L;

	public InvalidAdvisorId(String string) {
		// TODO Auto-generated constructor stub
		System.out.println(string);
	}
}
