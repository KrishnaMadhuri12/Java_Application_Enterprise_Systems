/*************************************************************
* File: InvalidAdvisor.java
* Project: AppointmentSystem
* Versions:
*	1.1	February 2017
*
* Description:
* This an exception which is thrown when the provided Student Id does not exist in system
* 
* @author Krishna Madhuri
**************************************************************/
package com.university.exception;


public class InvalidStudentId extends Exception{
	private static final long serialVersionUID = 444308296604489447L;

	public InvalidStudentId(String msg){
		System.out.println(msg);
	}
}
