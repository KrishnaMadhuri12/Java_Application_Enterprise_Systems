/*************************************************************
* File:AdvisorServiceImp.java
* Project: AppointmentSystem
* Versions:
*	1.1	February 2017
*
* Description:
* This class implements the AdvisorService interface
* @author Krishna Madhuri
**************************************************************/
package com.university.impl;

import com.university.dao.AdvisorDAO;
import com.university.dto.Advisor;
import com.university.exception.InvalidAdvisorId;
import com.university.service.AdvisorService;

public class AdvisorServiceImp implements AdvisorService{
	AdvisorDAO advisorRef= new AdvisorDAO();
	public Advisor verifyAdvisor(int id) throws InvalidAdvisorId {
		
		return advisorRef.verifyAdvisor(id);
	}

	public void viewAppointments(Advisor advisorDetails) {
		advisorRef.viewAppointments(advisorDetails);		
	}

	public void bookAppointment(Advisor advisorDetails, int id,int studentId) {
		advisorRef.bookAppointment(advisorDetails, id, studentId);
		
	}

	public void modifyAppointment(int apt_id,int reqtimeSlot){
		advisorRef.modifyAppointment(apt_id, reqtimeSlot);
		
	}

	public void  cancelAppointment(Advisor advisorDetails, int apt_id) {
		advisorRef.cancelAppointment(advisorDetails, apt_id);
	}
	public void viewTimeSlot(Advisor advisorDetails)
	{
		advisorRef.viewTimeSlot(advisorDetails);
	}
	
	

}
