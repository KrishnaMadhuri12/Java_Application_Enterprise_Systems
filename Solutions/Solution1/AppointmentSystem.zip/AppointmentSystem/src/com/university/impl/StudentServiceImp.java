/**
 * 
 */
package com.university.impl;

import com.university.dao.StudentDAO;
import com.university.dto.Student;
import com.university.exception.InvalidStudentId;
import com.university.service.StudentService;

/**
 * @author Madhuri
 *
 */
public class StudentServiceImp implements StudentService{
StudentDAO studentRef= new StudentDAO();
	public Student verifyStudent(int id) throws InvalidStudentId {
		
		return studentRef.verifyStudent(id);
	}

	public void viewAppointments(Student studentDetails) {
		studentRef.viewAppointments(studentDetails);		
	}

	public void bookAppointment(Student studentDetails, int id) {
		studentRef.bookAppointment(studentDetails, id);
		
	}

	public void modifyAppointment(Student studentDetails,int id,int timeSlotId) {
		studentRef.modifyAppointment(studentDetails,id, timeSlotId);
		
	}

	public void cancelAppointment(Student studentDetails, int id) {
		studentRef.cancelAppointment(studentDetails, id);
	}
	public void viewTimeSlot(Student studentDetails)
	{
		studentRef.viewTimeSlot(studentDetails);
	}

}
