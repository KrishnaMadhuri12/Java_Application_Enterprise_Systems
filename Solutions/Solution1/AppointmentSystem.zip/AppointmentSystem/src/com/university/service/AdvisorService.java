/*************************************************************
* File:AdvisorService.java
* Project: AppointmentSystem
* Versions:
*	1.1	February 2017
*
* Description:
* This is an interface with methods required to implement the advisor module
* 
* @author Krishna Madhuri
**************************************************************/
package com.university.service;

import com.university.dto.Advisor;
import com.university.exception.InvalidAdvisorId;

public interface AdvisorService {
	
	public Advisor verifyAdvisor(int id) throws InvalidAdvisorId;
	public void viewAppointments(Advisor advisorDetails);
	public void bookAppointment(Advisor advisorDetails, int id,int studentId);
	public void modifyAppointment(int apt_id,int reqtimeSlot);
	public void  cancelAppointment(Advisor advisorDetails, int apt_id);
	public void viewTimeSlot(Advisor advisorDetails);
	
}
