/**
 * 
 */
package com.university.service;

import com.university.dto.Student;
import com.university.exception.InvalidStudentId;

/**
 * @author Madhuri
 *
 */
public interface StudentService {
	
	public Student verifyStudent(int id) throws InvalidStudentId;
	public void viewAppointments(Student studentDetails);
	public void bookAppointment(Student studentDetails, int id);
	public void modifyAppointment(Student studentDetails,int id,int timeSlotId);
	public void cancelAppointment(Student studentDetails, int id);
	public void viewTimeSlot(Student studentDetails);

}
